void writeOnFile(List<int> bytes) {}

List<int> fileToBytes(dynamic data) {
  throw UnimplementedError();
}
