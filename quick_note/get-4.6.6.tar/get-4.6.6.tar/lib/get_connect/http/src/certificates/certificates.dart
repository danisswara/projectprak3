class TrustedCertificate {
  final List<int> bytes;

  TrustedCertificate(this.bytes);
}
