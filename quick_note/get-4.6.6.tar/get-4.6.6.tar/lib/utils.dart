/// Get utils is a set of tools that allows you to access high-level
/// APIs and obtain validation tools for Flutter and GetX
library utils;

export 'get_core/get_core.dart';
export 'get_utils/get_utils.dart';
