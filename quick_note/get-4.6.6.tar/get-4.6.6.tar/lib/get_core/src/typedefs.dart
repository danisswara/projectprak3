typedef ValueUpdater<T> = T Function();
