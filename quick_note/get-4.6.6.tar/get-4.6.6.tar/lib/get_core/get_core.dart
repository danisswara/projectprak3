library get_core;

export 'src/get_interface.dart';
export 'src/get_main.dart';
export 'src/log.dart';
export 'src/smart_management.dart';
export 'src/typedefs.dart';

T? ambiguate<T>(T? value) => value;
