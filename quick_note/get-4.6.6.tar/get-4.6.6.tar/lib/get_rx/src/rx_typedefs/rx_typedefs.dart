typedef Condition = bool Function();
typedef OnData<T> = void Function(T data);
typedef Callback = void Function();
