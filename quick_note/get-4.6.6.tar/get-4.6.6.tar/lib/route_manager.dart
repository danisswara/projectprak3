///Get Navigator allows you to navigate routes, open snackbars,
///dialogs and bottomsheets easily, and without the need for context.
library route_manager;

export 'get_core/get_core.dart';
export 'get_navigation/get_navigation.dart';
