part of 'app_pages.dart';

abstract class Routes {
  static const HOME = '/home';
  static const COUNTRY = '/country';
  static const DETAILS = '/details';
}
