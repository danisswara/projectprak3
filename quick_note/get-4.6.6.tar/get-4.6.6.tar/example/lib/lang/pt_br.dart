// ignore_for_file: file_names

const Map<String, String> pt_BR = {
  'covid': 'Corona Vírus',
  'total_confirmed': 'Total confirmado',
  'total_deaths': 'Total de mortes',
  'fetch_country': 'Listar por país',
  'corona_by_country': 'Corona por país',
  'total_infecteds': 'Total de infectados',
  'details': 'Detalhes',
  'total_recovered': 'Total de recuperados'
};
